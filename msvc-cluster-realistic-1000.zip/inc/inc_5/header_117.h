#ifndef header_117_h
#define header_117_h
class GenClass_117 {
int i;
};
#endif
