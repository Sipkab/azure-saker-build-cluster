#ifndef header_102_h
#define header_102_h
class GenClass_102 {
int i;
};
#endif
