#ifndef header_103_h
#define header_103_h
class GenClass_103 {
int i;
};
#endif
