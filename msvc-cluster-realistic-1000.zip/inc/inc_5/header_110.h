#ifndef header_110_h
#define header_110_h
class GenClass_110 {
int i;
};
#endif
