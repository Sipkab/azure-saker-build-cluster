#ifndef header_108_h
#define header_108_h
class GenClass_108 {
int i;
};
#endif
