#ifndef header_112_h
#define header_112_h
class GenClass_112 {
int i;
};
#endif
