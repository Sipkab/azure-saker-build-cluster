#ifndef header_106_h
#define header_106_h
class GenClass_106 {
int i;
};
#endif
