#ifndef header_105_h
#define header_105_h
class GenClass_105 {
int i;
};
#endif
