#ifndef header_119_h
#define header_119_h
class GenClass_119 {
int i;
};
#endif
