#ifndef header_115_h
#define header_115_h
class GenClass_115 {
int i;
};
#endif
