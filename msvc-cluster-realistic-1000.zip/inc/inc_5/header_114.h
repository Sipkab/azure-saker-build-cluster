#ifndef header_114_h
#define header_114_h
class GenClass_114 {
int i;
};
#endif
