#ifndef header_104_h
#define header_104_h
class GenClass_104 {
int i;
};
#endif
