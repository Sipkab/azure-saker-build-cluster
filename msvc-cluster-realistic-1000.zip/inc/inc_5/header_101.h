#ifndef header_101_h
#define header_101_h
class GenClass_101 {
int i;
};
#endif
