#ifndef header_113_h
#define header_113_h
class GenClass_113 {
int i;
};
#endif
