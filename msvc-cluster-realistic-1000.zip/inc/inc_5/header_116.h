#ifndef header_116_h
#define header_116_h
class GenClass_116 {
int i;
};
#endif
