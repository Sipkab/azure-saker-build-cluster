#ifndef header_118_h
#define header_118_h
class GenClass_118 {
int i;
};
#endif
