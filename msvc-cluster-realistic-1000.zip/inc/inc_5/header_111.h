#ifndef header_111_h
#define header_111_h
class GenClass_111 {
int i;
};
#endif
