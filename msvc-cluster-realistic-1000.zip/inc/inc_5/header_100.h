#ifndef header_100_h
#define header_100_h
class GenClass_100 {
int i;
};
#endif
