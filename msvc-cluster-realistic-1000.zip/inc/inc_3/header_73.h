#ifndef header_73_h
#define header_73_h
class GenClass_73 {
int i;
};
#endif
