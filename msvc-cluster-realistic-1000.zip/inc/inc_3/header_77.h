#ifndef header_77_h
#define header_77_h
class GenClass_77 {
int i;
};
#endif
