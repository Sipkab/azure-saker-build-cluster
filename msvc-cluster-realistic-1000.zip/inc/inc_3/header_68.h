#ifndef header_68_h
#define header_68_h
class GenClass_68 {
int i;
};
#endif
