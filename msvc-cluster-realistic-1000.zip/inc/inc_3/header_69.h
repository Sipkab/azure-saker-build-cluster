#ifndef header_69_h
#define header_69_h
class GenClass_69 {
int i;
};
#endif
