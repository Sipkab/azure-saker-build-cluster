#ifndef header_79_h
#define header_79_h
class GenClass_79 {
int i;
};
#endif
