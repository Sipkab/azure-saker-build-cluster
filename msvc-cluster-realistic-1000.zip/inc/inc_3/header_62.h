#ifndef header_62_h
#define header_62_h
class GenClass_62 {
int i;
};
#endif
