#ifndef header_61_h
#define header_61_h
class GenClass_61 {
int i;
};
#endif
