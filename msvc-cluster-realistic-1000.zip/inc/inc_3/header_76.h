#ifndef header_76_h
#define header_76_h
class GenClass_76 {
int i;
};
#endif
