#ifndef header_65_h
#define header_65_h
class GenClass_65 {
int i;
};
#endif
