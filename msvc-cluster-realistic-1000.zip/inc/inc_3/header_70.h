#ifndef header_70_h
#define header_70_h
class GenClass_70 {
int i;
};
#endif
