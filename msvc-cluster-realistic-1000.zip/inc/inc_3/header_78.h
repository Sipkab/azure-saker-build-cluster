#ifndef header_78_h
#define header_78_h
class GenClass_78 {
int i;
};
#endif
