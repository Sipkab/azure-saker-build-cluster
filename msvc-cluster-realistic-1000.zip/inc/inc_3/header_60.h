#ifndef header_60_h
#define header_60_h
class GenClass_60 {
int i;
};
#endif
