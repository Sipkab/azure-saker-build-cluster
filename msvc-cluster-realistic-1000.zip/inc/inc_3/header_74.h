#ifndef header_74_h
#define header_74_h
class GenClass_74 {
int i;
};
#endif
