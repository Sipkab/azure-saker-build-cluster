#ifndef header_67_h
#define header_67_h
class GenClass_67 {
int i;
};
#endif
