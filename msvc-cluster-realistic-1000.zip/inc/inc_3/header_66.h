#ifndef header_66_h
#define header_66_h
class GenClass_66 {
int i;
};
#endif
