#ifndef header_72_h
#define header_72_h
class GenClass_72 {
int i;
};
#endif
