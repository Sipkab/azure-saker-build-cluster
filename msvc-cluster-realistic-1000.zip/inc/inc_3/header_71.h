#ifndef header_71_h
#define header_71_h
class GenClass_71 {
int i;
};
#endif
