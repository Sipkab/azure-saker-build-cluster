#ifndef header_64_h
#define header_64_h
class GenClass_64 {
int i;
};
#endif
