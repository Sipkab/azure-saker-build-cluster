#ifndef header_127_h
#define header_127_h
class GenClass_127 {
int i;
};
#endif
