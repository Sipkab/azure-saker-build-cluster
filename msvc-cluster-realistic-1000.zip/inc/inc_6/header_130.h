#ifndef header_130_h
#define header_130_h
class GenClass_130 {
int i;
};
#endif
