#ifndef header_132_h
#define header_132_h
class GenClass_132 {
int i;
};
#endif
