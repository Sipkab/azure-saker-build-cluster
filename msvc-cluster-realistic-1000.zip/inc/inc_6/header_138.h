#ifndef header_138_h
#define header_138_h
class GenClass_138 {
int i;
};
#endif
