#ifndef header_123_h
#define header_123_h
class GenClass_123 {
int i;
};
#endif
