#ifndef header_125_h
#define header_125_h
class GenClass_125 {
int i;
};
#endif
