#ifndef header_126_h
#define header_126_h
class GenClass_126 {
int i;
};
#endif
