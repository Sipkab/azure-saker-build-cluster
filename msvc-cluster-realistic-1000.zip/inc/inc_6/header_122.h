#ifndef header_122_h
#define header_122_h
class GenClass_122 {
int i;
};
#endif
