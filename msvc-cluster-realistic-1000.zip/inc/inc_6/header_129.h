#ifndef header_129_h
#define header_129_h
class GenClass_129 {
int i;
};
#endif
