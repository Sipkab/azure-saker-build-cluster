#ifndef header_128_h
#define header_128_h
class GenClass_128 {
int i;
};
#endif
