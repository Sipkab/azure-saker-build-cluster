#ifndef header_120_h
#define header_120_h
class GenClass_120 {
int i;
};
#endif
