#ifndef header_124_h
#define header_124_h
class GenClass_124 {
int i;
};
#endif
