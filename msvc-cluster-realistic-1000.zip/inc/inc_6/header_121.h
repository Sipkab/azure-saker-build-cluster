#ifndef header_121_h
#define header_121_h
class GenClass_121 {
int i;
};
#endif
