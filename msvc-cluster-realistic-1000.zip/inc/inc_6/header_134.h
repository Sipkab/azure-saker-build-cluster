#ifndef header_134_h
#define header_134_h
class GenClass_134 {
int i;
};
#endif
