#ifndef header_26_h
#define header_26_h
class GenClass_26 {
int i;
};
#endif
