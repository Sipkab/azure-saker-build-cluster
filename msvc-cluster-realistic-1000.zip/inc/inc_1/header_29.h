#ifndef header_29_h
#define header_29_h
class GenClass_29 {
int i;
};
#endif
