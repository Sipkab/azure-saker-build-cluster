#ifndef header_37_h
#define header_37_h
class GenClass_37 {
int i;
};
#endif
