#ifndef header_25_h
#define header_25_h
class GenClass_25 {
int i;
};
#endif
