#ifndef header_34_h
#define header_34_h
class GenClass_34 {
int i;
};
#endif
