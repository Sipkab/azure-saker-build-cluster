#ifndef header_31_h
#define header_31_h
class GenClass_31 {
int i;
};
#endif
