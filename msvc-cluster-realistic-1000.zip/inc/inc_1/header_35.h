#ifndef header_35_h
#define header_35_h
class GenClass_35 {
int i;
};
#endif
