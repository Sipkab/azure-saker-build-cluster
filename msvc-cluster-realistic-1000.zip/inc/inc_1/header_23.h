#ifndef header_23_h
#define header_23_h
class GenClass_23 {
int i;
};
#endif
