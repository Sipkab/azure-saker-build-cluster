#ifndef header_38_h
#define header_38_h
class GenClass_38 {
int i;
};
#endif
