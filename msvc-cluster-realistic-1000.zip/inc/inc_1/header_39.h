#ifndef header_39_h
#define header_39_h
class GenClass_39 {
int i;
};
#endif
