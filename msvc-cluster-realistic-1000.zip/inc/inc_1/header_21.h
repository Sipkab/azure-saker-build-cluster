#ifndef header_21_h
#define header_21_h
class GenClass_21 {
int i;
};
#endif
