#ifndef header_33_h
#define header_33_h
class GenClass_33 {
int i;
};
#endif
