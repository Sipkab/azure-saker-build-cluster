#ifndef header_20_h
#define header_20_h
class GenClass_20 {
int i;
};
#endif
