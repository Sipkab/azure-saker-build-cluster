#ifndef header_24_h
#define header_24_h
class GenClass_24 {
int i;
};
#endif
