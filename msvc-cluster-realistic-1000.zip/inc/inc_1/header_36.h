#ifndef header_36_h
#define header_36_h
class GenClass_36 {
int i;
};
#endif
