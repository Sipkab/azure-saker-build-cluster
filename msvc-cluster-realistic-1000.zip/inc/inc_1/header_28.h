#ifndef header_28_h
#define header_28_h
class GenClass_28 {
int i;
};
#endif
