#ifndef header_22_h
#define header_22_h
class GenClass_22 {
int i;
};
#endif
