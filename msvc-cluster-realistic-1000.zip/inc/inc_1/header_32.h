#ifndef header_32_h
#define header_32_h
class GenClass_32 {
int i;
};
#endif
