#ifndef header_27_h
#define header_27_h
class GenClass_27 {
int i;
};
#endif
