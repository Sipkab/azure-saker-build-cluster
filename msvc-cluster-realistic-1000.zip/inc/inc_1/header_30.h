#ifndef header_30_h
#define header_30_h
class GenClass_30 {
int i;
};
#endif
