#ifndef header_50_h
#define header_50_h
class GenClass_50 {
int i;
};
#endif
