#ifndef header_51_h
#define header_51_h
class GenClass_51 {
int i;
};
#endif
