#ifndef header_49_h
#define header_49_h
class GenClass_49 {
int i;
};
#endif
