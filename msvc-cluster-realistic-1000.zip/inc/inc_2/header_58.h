#ifndef header_58_h
#define header_58_h
class GenClass_58 {
int i;
};
#endif
