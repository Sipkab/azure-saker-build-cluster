#ifndef header_41_h
#define header_41_h
class GenClass_41 {
int i;
};
#endif
