#ifndef header_42_h
#define header_42_h
class GenClass_42 {
int i;
};
#endif
