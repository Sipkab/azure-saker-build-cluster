#ifndef header_47_h
#define header_47_h
class GenClass_47 {
int i;
};
#endif
