#ifndef header_55_h
#define header_55_h
class GenClass_55 {
int i;
};
#endif
