#ifndef header_46_h
#define header_46_h
class GenClass_46 {
int i;
};
#endif
