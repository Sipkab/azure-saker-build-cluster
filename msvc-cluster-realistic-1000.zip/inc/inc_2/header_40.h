#ifndef header_40_h
#define header_40_h
class GenClass_40 {
int i;
};
#endif
