#ifndef header_53_h
#define header_53_h
class GenClass_53 {
int i;
};
#endif
