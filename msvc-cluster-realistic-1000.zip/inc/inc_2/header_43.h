#ifndef header_43_h
#define header_43_h
class GenClass_43 {
int i;
};
#endif
