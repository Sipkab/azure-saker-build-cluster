#ifndef header_52_h
#define header_52_h
class GenClass_52 {
int i;
};
#endif
