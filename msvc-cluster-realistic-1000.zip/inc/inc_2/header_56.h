#ifndef header_56_h
#define header_56_h
class GenClass_56 {
int i;
};
#endif
