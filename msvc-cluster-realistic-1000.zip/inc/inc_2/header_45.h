#ifndef header_45_h
#define header_45_h
class GenClass_45 {
int i;
};
#endif
