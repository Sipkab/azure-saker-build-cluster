#ifndef header_57_h
#define header_57_h
class GenClass_57 {
int i;
};
#endif
