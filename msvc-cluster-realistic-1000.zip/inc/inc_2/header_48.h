#ifndef header_48_h
#define header_48_h
class GenClass_48 {
int i;
};
#endif
