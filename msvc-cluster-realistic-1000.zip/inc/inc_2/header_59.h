#ifndef header_59_h
#define header_59_h
class GenClass_59 {
int i;
};
#endif
