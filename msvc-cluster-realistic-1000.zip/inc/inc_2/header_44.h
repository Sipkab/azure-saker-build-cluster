#ifndef header_44_h
#define header_44_h
class GenClass_44 {
int i;
};
#endif
