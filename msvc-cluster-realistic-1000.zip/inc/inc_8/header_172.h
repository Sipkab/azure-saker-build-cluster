#ifndef header_172_h
#define header_172_h
class GenClass_172 {
int i;
};
#endif
