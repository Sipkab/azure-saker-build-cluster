#ifndef header_162_h
#define header_162_h
class GenClass_162 {
int i;
};
#endif
