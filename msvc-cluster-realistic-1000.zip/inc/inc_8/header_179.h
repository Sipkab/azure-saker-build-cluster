#ifndef header_179_h
#define header_179_h
class GenClass_179 {
int i;
};
#endif
