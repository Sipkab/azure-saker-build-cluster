#ifndef header_166_h
#define header_166_h
class GenClass_166 {
int i;
};
#endif
