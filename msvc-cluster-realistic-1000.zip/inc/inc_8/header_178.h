#ifndef header_178_h
#define header_178_h
class GenClass_178 {
int i;
};
#endif
