#ifndef header_161_h
#define header_161_h
class GenClass_161 {
int i;
};
#endif
