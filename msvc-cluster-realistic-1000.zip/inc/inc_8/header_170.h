#ifndef header_170_h
#define header_170_h
class GenClass_170 {
int i;
};
#endif
