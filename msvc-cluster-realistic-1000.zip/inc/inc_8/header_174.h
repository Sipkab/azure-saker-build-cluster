#ifndef header_174_h
#define header_174_h
class GenClass_174 {
int i;
};
#endif
