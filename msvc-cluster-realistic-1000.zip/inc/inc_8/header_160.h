#ifndef header_160_h
#define header_160_h
class GenClass_160 {
int i;
};
#endif
