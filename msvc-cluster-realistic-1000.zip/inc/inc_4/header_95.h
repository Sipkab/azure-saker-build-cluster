#ifndef header_95_h
#define header_95_h
class GenClass_95 {
int i;
};
#endif
