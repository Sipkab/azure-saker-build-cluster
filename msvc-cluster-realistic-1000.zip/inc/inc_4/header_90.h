#ifndef header_90_h
#define header_90_h
class GenClass_90 {
int i;
};
#endif
