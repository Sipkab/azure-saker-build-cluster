#ifndef header_83_h
#define header_83_h
class GenClass_83 {
int i;
};
#endif
