#ifndef header_85_h
#define header_85_h
class GenClass_85 {
int i;
};
#endif
