#ifndef header_99_h
#define header_99_h
class GenClass_99 {
int i;
};
#endif
