#ifndef header_96_h
#define header_96_h
class GenClass_96 {
int i;
};
#endif
