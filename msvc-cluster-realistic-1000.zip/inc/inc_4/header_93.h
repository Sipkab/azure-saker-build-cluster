#ifndef header_93_h
#define header_93_h
class GenClass_93 {
int i;
};
#endif
