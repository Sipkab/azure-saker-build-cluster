#ifndef header_89_h
#define header_89_h
class GenClass_89 {
int i;
};
#endif
