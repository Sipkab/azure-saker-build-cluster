#ifndef header_82_h
#define header_82_h
class GenClass_82 {
int i;
};
#endif
