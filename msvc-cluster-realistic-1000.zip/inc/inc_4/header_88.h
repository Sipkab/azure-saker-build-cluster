#ifndef header_88_h
#define header_88_h
class GenClass_88 {
int i;
};
#endif
