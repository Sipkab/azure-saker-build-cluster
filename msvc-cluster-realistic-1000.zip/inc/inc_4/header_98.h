#ifndef header_98_h
#define header_98_h
class GenClass_98 {
int i;
};
#endif
