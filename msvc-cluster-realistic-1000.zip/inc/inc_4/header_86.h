#ifndef header_86_h
#define header_86_h
class GenClass_86 {
int i;
};
#endif
