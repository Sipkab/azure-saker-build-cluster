#ifndef header_84_h
#define header_84_h
class GenClass_84 {
int i;
};
#endif
