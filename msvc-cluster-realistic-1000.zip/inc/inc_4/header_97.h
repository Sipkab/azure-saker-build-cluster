#ifndef header_97_h
#define header_97_h
class GenClass_97 {
int i;
};
#endif
