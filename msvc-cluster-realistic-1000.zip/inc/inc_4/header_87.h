#ifndef header_87_h
#define header_87_h
class GenClass_87 {
int i;
};
#endif
