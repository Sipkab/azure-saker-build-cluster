#ifndef header_94_h
#define header_94_h
class GenClass_94 {
int i;
};
#endif
