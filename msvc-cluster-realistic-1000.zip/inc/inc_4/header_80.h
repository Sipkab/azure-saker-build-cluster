#ifndef header_80_h
#define header_80_h
class GenClass_80 {
int i;
};
#endif
