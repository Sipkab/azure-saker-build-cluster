#ifndef header_92_h
#define header_92_h
class GenClass_92 {
int i;
};
#endif
