#ifndef header_195_h
#define header_195_h
class GenClass_195 {
int i;
};
#endif
