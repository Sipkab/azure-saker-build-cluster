#ifndef header_196_h
#define header_196_h
class GenClass_196 {
int i;
};
#endif
