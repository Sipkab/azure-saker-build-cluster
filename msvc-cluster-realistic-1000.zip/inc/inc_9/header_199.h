#ifndef header_199_h
#define header_199_h
class GenClass_199 {
int i;
};
#endif
