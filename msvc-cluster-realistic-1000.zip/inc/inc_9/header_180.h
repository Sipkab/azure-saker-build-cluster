#ifndef header_180_h
#define header_180_h
class GenClass_180 {
int i;
};
#endif
