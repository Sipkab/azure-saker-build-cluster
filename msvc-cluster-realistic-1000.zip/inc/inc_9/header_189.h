#ifndef header_189_h
#define header_189_h
class GenClass_189 {
int i;
};
#endif
