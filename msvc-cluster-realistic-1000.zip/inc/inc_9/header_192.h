#ifndef header_192_h
#define header_192_h
class GenClass_192 {
int i;
};
#endif
