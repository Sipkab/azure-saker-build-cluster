#ifndef header_193_h
#define header_193_h
class GenClass_193 {
int i;
};
#endif
