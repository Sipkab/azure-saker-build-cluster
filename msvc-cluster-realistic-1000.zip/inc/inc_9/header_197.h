#ifndef header_197_h
#define header_197_h
class GenClass_197 {
int i;
};
#endif
