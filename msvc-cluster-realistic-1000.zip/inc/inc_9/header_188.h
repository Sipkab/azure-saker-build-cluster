#ifndef header_188_h
#define header_188_h
class GenClass_188 {
int i;
};
#endif
