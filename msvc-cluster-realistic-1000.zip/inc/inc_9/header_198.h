#ifndef header_198_h
#define header_198_h
class GenClass_198 {
int i;
};
#endif
