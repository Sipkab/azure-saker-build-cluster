#ifndef header_183_h
#define header_183_h
class GenClass_183 {
int i;
};
#endif
