#ifndef header_185_h
#define header_185_h
class GenClass_185 {
int i;
};
#endif
