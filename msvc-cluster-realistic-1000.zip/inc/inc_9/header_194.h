#ifndef header_194_h
#define header_194_h
class GenClass_194 {
int i;
};
#endif
