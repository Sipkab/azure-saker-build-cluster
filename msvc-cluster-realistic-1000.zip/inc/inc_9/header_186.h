#ifndef header_186_h
#define header_186_h
class GenClass_186 {
int i;
};
#endif
