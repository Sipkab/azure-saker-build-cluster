#ifndef header_190_h
#define header_190_h
class GenClass_190 {
int i;
};
#endif
