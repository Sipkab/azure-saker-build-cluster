#ifndef header_150_h
#define header_150_h
class GenClass_150 {
int i;
};
#endif
