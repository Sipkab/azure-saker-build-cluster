#ifndef header_149_h
#define header_149_h
class GenClass_149 {
int i;
};
#endif
