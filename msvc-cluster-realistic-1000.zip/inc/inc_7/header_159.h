#ifndef header_159_h
#define header_159_h
class GenClass_159 {
int i;
};
#endif
