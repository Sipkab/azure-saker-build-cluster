#ifndef header_157_h
#define header_157_h
class GenClass_157 {
int i;
};
#endif
