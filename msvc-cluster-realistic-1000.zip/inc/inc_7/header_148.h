#ifndef header_148_h
#define header_148_h
class GenClass_148 {
int i;
};
#endif
