#ifndef header_141_h
#define header_141_h
class GenClass_141 {
int i;
};
#endif
