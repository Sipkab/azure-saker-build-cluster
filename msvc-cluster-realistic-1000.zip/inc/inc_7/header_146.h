#ifndef header_146_h
#define header_146_h
class GenClass_146 {
int i;
};
#endif
