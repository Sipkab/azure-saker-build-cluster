#ifndef header_140_h
#define header_140_h
class GenClass_140 {
int i;
};
#endif
