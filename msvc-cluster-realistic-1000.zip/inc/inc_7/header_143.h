#ifndef header_143_h
#define header_143_h
class GenClass_143 {
int i;
};
#endif
