#ifndef header_158_h
#define header_158_h
class GenClass_158 {
int i;
};
#endif
