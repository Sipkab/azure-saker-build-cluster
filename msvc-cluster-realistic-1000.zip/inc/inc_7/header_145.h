#ifndef header_145_h
#define header_145_h
class GenClass_145 {
int i;
};
#endif
