#ifndef header_152_h
#define header_152_h
class GenClass_152 {
int i;
};
#endif
