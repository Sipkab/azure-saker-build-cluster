#ifndef header_154_h
#define header_154_h
class GenClass_154 {
int i;
};
#endif
