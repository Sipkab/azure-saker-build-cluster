#ifndef header_156_h
#define header_156_h
class GenClass_156 {
int i;
};
#endif
