#ifndef header_155_h
#define header_155_h
class GenClass_155 {
int i;
};
#endif
