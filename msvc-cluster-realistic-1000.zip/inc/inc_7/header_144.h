#ifndef header_144_h
#define header_144_h
class GenClass_144 {
int i;
};
#endif
