#ifndef header_142_h
#define header_142_h
class GenClass_142 {
int i;
};
#endif
