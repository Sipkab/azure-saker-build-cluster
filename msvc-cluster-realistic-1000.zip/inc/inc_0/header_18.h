#ifndef header_18_h
#define header_18_h
class GenClass_18 {
int i;
};
#endif
