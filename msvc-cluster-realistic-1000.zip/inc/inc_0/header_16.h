#ifndef header_16_h
#define header_16_h
class GenClass_16 {
int i;
};
#endif
