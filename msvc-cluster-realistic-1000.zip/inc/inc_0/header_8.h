#ifndef header_8_h
#define header_8_h
class GenClass_8 {
int i;
};
#endif
