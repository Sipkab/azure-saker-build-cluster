#ifndef header_13_h
#define header_13_h
class GenClass_13 {
int i;
};
#endif
