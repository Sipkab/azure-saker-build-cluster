#ifndef header_3_h
#define header_3_h
class GenClass_3 {
int i;
};
#endif
