#ifndef header_17_h
#define header_17_h
class GenClass_17 {
int i;
};
#endif
