#ifndef header_4_h
#define header_4_h
class GenClass_4 {
int i;
};
#endif
