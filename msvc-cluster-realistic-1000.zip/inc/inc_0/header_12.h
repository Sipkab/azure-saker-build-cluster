#ifndef header_12_h
#define header_12_h
class GenClass_12 {
int i;
};
#endif
