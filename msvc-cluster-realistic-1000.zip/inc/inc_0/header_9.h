#ifndef header_9_h
#define header_9_h
class GenClass_9 {
int i;
};
#endif
