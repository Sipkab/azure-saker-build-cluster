#ifndef header_15_h
#define header_15_h
class GenClass_15 {
int i;
};
#endif
