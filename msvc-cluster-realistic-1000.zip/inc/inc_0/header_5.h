#ifndef header_5_h
#define header_5_h
class GenClass_5 {
int i;
};
#endif
