#ifndef header_7_h
#define header_7_h
class GenClass_7 {
int i;
};
#endif
