#ifndef header_1_h
#define header_1_h
class GenClass_1 {
int i;
};
#endif
