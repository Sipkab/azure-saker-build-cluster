#ifndef header_2_h
#define header_2_h
class GenClass_2 {
int i;
};
#endif
