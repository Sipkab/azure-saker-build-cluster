#ifndef header_19_h
#define header_19_h
class GenClass_19 {
int i;
};
#endif
