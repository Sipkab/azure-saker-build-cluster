#ifndef header_10_h
#define header_10_h
class GenClass_10 {
int i;
};
#endif
