#ifndef header_0_h
#define header_0_h
class GenClass_0 {
int i;
};
#endif
