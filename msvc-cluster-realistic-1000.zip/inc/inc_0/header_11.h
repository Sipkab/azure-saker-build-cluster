#ifndef header_11_h
#define header_11_h
class GenClass_11 {
int i;
};
#endif
