#ifndef header_6_h
#define header_6_h
class GenClass_6 {
int i;
};
#endif
