#include <Windows.h>
#include <vector>
#include <inc_4/header_91.h>
static_assert(sizeof(GenClass_91) > 0, "failed");
std::vector<int> perf_func_517() {
    LoadLibrary("abc.dll");
    return {517};
}
