#include <Windows.h>
#include <vector>
#include <inc_2/header_47.h>
static_assert(sizeof(GenClass_47) > 0, "failed");
#include <inc_5/header_117.h>
static_assert(sizeof(GenClass_117) > 0, "failed");
std::vector<int> perf_func_514() {
    LoadLibrary("abc.dll");
    return {514};
}
