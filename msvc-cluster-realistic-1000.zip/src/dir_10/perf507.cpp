#include <Windows.h>
#include <vector>
#include <inc_4/header_98.h>
static_assert(sizeof(GenClass_98) > 0, "failed");
std::vector<int> perf_func_507() {
    LoadLibrary("abc.dll");
    return {507};
}
