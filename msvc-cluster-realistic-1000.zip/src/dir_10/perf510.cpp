#include <Windows.h>
#include <vector>
#include <inc_7/header_155.h>
static_assert(sizeof(GenClass_155) > 0, "failed");
#include <inc_6/header_125.h>
static_assert(sizeof(GenClass_125) > 0, "failed");
std::vector<int> perf_func_510() {
    LoadLibrary("abc.dll");
    return {510};
}
