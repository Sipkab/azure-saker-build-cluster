#include <Windows.h>
#include <vector>
#include <inc_8/header_172.h>
static_assert(sizeof(GenClass_172) > 0, "failed");
std::vector<int> perf_func_536() {
    LoadLibrary("abc.dll");
    return {536};
}
