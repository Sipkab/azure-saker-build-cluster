#include <Windows.h>
#include <vector>
#include <inc_8/header_167.h>
static_assert(sizeof(GenClass_167) > 0, "failed");
#include <inc_2/header_42.h>
static_assert(sizeof(GenClass_42) > 0, "failed");
#include <inc_1/header_36.h>
static_assert(sizeof(GenClass_36) > 0, "failed");
std::vector<int> perf_func_527() {
    LoadLibrary("abc.dll");
    return {527};
}
