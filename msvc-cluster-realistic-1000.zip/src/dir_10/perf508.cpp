#include <Windows.h>
#include <vector>
#include <inc_2/header_51.h>
static_assert(sizeof(GenClass_51) > 0, "failed");
#include <inc_5/header_118.h>
static_assert(sizeof(GenClass_118) > 0, "failed");
#include <inc_3/header_60.h>
static_assert(sizeof(GenClass_60) > 0, "failed");
std::vector<int> perf_func_508() {
    LoadLibrary("abc.dll");
    return {508};
}
