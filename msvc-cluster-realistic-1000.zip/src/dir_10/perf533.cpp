#include <Windows.h>
#include <vector>
#include <inc_6/header_120.h>
static_assert(sizeof(GenClass_120) > 0, "failed");
std::vector<int> perf_func_533() {
    LoadLibrary("abc.dll");
    return {533};
}
