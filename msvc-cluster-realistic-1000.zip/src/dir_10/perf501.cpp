#include <Windows.h>
#include <vector>
#include <inc_7/header_158.h>
static_assert(sizeof(GenClass_158) > 0, "failed");
std::vector<int> perf_func_501() {
    LoadLibrary("abc.dll");
    return {501};
}
