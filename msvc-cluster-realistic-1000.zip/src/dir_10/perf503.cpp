#include <Windows.h>
#include <vector>
#include <inc_1/header_23.h>
static_assert(sizeof(GenClass_23) > 0, "failed");
std::vector<int> perf_func_503() {
    LoadLibrary("abc.dll");
    return {503};
}
