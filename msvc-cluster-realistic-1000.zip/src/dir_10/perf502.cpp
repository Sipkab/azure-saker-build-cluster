#include <Windows.h>
#include <vector>
#include <inc_4/header_82.h>
static_assert(sizeof(GenClass_82) > 0, "failed");
std::vector<int> perf_func_502() {
    LoadLibrary("abc.dll");
    return {502};
}
