#include <Windows.h>
#include <vector>
#include <inc_1/header_22.h>
static_assert(sizeof(GenClass_22) > 0, "failed");
std::vector<int> perf_func_526() {
    LoadLibrary("abc.dll");
    return {526};
}
