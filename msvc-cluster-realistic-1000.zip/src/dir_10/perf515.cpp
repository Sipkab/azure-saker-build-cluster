#include <Windows.h>
#include <vector>
#include <inc_0/header_4.h>
static_assert(sizeof(GenClass_4) > 0, "failed");
std::vector<int> perf_func_515() {
    LoadLibrary("abc.dll");
    return {515};
}
