#include <Windows.h>
#include <vector>
#include <inc_4/header_84.h>
static_assert(sizeof(GenClass_84) > 0, "failed");
std::vector<int> perf_func_529() {
    LoadLibrary("abc.dll");
    return {529};
}
