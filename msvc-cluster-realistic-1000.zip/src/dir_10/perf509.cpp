#include <Windows.h>
#include <vector>
#include <inc_2/header_51.h>
static_assert(sizeof(GenClass_51) > 0, "failed");
#include <inc_9/header_180.h>
static_assert(sizeof(GenClass_180) > 0, "failed");
std::vector<int> perf_func_509() {
    LoadLibrary("abc.dll");
    return {509};
}
