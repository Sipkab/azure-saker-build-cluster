#include <Windows.h>
#include <vector>
#include <inc_5/header_109.h>
static_assert(sizeof(GenClass_109) > 0, "failed");
#include <inc_8/header_170.h>
static_assert(sizeof(GenClass_170) > 0, "failed");
std::vector<int> perf_func_687() {
    LoadLibrary("abc.dll");
    return {687};
}
