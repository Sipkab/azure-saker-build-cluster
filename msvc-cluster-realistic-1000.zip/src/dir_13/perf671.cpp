#include <Windows.h>
#include <vector>
#include <inc_5/header_117.h>
static_assert(sizeof(GenClass_117) > 0, "failed");
#include <inc_2/header_50.h>
static_assert(sizeof(GenClass_50) > 0, "failed");
std::vector<int> perf_func_671() {
    LoadLibrary("abc.dll");
    return {671};
}
