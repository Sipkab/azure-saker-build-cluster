#include <Windows.h>
#include <vector>
#include <inc_1/header_35.h>
static_assert(sizeof(GenClass_35) > 0, "failed");
#include <inc_5/header_115.h>
static_assert(sizeof(GenClass_115) > 0, "failed");
std::vector<int> perf_func_688() {
    LoadLibrary("abc.dll");
    return {688};
}
