#include <Windows.h>
#include <vector>
#include <inc_6/header_131.h>
static_assert(sizeof(GenClass_131) > 0, "failed");
std::vector<int> perf_func_686() {
    LoadLibrary("abc.dll");
    return {686};
}
