#include <Windows.h>
#include <vector>
#include <inc_0/header_1.h>
static_assert(sizeof(GenClass_1) > 0, "failed");
#include <inc_8/header_175.h>
static_assert(sizeof(GenClass_175) > 0, "failed");
std::vector<int> perf_func_680() {
    LoadLibrary("abc.dll");
    return {680};
}
