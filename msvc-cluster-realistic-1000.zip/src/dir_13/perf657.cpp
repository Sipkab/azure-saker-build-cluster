#include <Windows.h>
#include <vector>
#include <inc_8/header_177.h>
static_assert(sizeof(GenClass_177) > 0, "failed");
std::vector<int> perf_func_657() {
    LoadLibrary("abc.dll");
    return {657};
}
