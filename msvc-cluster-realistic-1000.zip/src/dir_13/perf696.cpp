#include <Windows.h>
#include <vector>
#include <inc_9/header_187.h>
static_assert(sizeof(GenClass_187) > 0, "failed");
std::vector<int> perf_func_696() {
    LoadLibrary("abc.dll");
    return {696};
}
