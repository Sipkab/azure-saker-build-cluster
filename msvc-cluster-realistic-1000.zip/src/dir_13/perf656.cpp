#include <Windows.h>
#include <vector>
#include <inc_3/header_63.h>
static_assert(sizeof(GenClass_63) > 0, "failed");
#include <inc_6/header_125.h>
static_assert(sizeof(GenClass_125) > 0, "failed");
std::vector<int> perf_func_656() {
    LoadLibrary("abc.dll");
    return {656};
}
