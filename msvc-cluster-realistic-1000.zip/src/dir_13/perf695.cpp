#include <Windows.h>
#include <vector>
#include <inc_8/header_169.h>
static_assert(sizeof(GenClass_169) > 0, "failed");
std::vector<int> perf_func_695() {
    LoadLibrary("abc.dll");
    return {695};
}
