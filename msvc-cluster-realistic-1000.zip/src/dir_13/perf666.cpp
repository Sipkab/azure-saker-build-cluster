#include <Windows.h>
#include <vector>
#include <inc_0/header_14.h>
static_assert(sizeof(GenClass_14) > 0, "failed");
#include <inc_8/header_173.h>
static_assert(sizeof(GenClass_173) > 0, "failed");
std::vector<int> perf_func_666() {
    LoadLibrary("abc.dll");
    return {666};
}
