#include <Windows.h>
#include <vector>
#include <inc_7/header_151.h>
static_assert(sizeof(GenClass_151) > 0, "failed");
#include <inc_2/header_57.h>
static_assert(sizeof(GenClass_57) > 0, "failed");
std::vector<int> perf_func_652() {
    LoadLibrary("abc.dll");
    return {652};
}
