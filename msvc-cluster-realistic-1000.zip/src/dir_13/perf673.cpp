#include <Windows.h>
#include <vector>
#include <inc_2/header_44.h>
static_assert(sizeof(GenClass_44) > 0, "failed");
#include <inc_3/header_69.h>
static_assert(sizeof(GenClass_69) > 0, "failed");
std::vector<int> perf_func_673() {
    LoadLibrary("abc.dll");
    return {673};
}
