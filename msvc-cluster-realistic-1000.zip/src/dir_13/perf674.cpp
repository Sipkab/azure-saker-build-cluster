#include <Windows.h>
#include <vector>
#include <inc_5/header_119.h>
static_assert(sizeof(GenClass_119) > 0, "failed");
std::vector<int> perf_func_674() {
    LoadLibrary("abc.dll");
    return {674};
}
