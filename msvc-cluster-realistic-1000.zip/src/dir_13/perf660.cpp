#include <Windows.h>
#include <vector>
#include <inc_8/header_167.h>
static_assert(sizeof(GenClass_167) > 0, "failed");
#include <inc_5/header_101.h>
static_assert(sizeof(GenClass_101) > 0, "failed");
#include <inc_8/header_175.h>
static_assert(sizeof(GenClass_175) > 0, "failed");
std::vector<int> perf_func_660() {
    LoadLibrary("abc.dll");
    return {660};
}
