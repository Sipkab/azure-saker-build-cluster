#include <Windows.h>
#include <vector>
#include <inc_4/header_90.h>
static_assert(sizeof(GenClass_90) > 0, "failed");
std::vector<int> perf_func_694() {
    LoadLibrary("abc.dll");
    return {694};
}
