#include <Windows.h>
#include <vector>
#include <inc_3/header_75.h>
static_assert(sizeof(GenClass_75) > 0, "failed");
std::vector<int> perf_func_658() {
    LoadLibrary("abc.dll");
    return {658};
}
