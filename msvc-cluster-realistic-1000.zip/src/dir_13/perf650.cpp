#include <Windows.h>
#include <vector>
#include <inc_1/header_37.h>
static_assert(sizeof(GenClass_37) > 0, "failed");
#include <inc_3/header_74.h>
static_assert(sizeof(GenClass_74) > 0, "failed");
#include <inc_3/header_63.h>
static_assert(sizeof(GenClass_63) > 0, "failed");
#include <inc_6/header_121.h>
static_assert(sizeof(GenClass_121) > 0, "failed");
std::vector<int> perf_func_650() {
    LoadLibrary("abc.dll");
    return {650};
}
