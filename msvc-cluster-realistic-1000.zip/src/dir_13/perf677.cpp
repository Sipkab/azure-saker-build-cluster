#include <Windows.h>
#include <vector>
#include <inc_1/header_21.h>
static_assert(sizeof(GenClass_21) > 0, "failed");
#include <inc_6/header_126.h>
static_assert(sizeof(GenClass_126) > 0, "failed");
std::vector<int> perf_func_677() {
    LoadLibrary("abc.dll");
    return {677};
}
