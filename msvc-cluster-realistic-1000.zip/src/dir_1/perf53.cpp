#include <Windows.h>
#include <vector>
#include <inc_7/header_148.h>
static_assert(sizeof(GenClass_148) > 0, "failed");
#include <inc_5/header_118.h>
static_assert(sizeof(GenClass_118) > 0, "failed");
std::vector<int> perf_func_53() {
    LoadLibrary("abc.dll");
    return {53};
}
