#include <Windows.h>
#include <vector>
#include <inc_7/header_149.h>
static_assert(sizeof(GenClass_149) > 0, "failed");
#include <inc_3/header_70.h>
static_assert(sizeof(GenClass_70) > 0, "failed");
std::vector<int> perf_func_77() {
    LoadLibrary("abc.dll");
    return {77};
}
