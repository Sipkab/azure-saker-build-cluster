#include <Windows.h>
#include <vector>
#include <inc_7/header_143.h>
static_assert(sizeof(GenClass_143) > 0, "failed");
std::vector<int> perf_func_66() {
    LoadLibrary("abc.dll");
    return {66};
}
