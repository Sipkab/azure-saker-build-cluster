#include <Windows.h>
#include <vector>
#include <inc_7/header_145.h>
static_assert(sizeof(GenClass_145) > 0, "failed");
#include <inc_3/header_65.h>
static_assert(sizeof(GenClass_65) > 0, "failed");
std::vector<int> perf_func_81() {
    LoadLibrary("abc.dll");
    return {81};
}
