#include <Windows.h>
#include <vector>
#include <inc_0/header_3.h>
static_assert(sizeof(GenClass_3) > 0, "failed");
std::vector<int> perf_func_91() {
    LoadLibrary("abc.dll");
    return {91};
}
