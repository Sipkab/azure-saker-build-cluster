#include <Windows.h>
#include <vector>
#include <inc_2/header_47.h>
static_assert(sizeof(GenClass_47) > 0, "failed");
std::vector<int> perf_func_83() {
    LoadLibrary("abc.dll");
    return {83};
}
