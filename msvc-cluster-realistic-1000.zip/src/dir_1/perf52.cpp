#include <Windows.h>
#include <vector>
#include <inc_4/header_85.h>
static_assert(sizeof(GenClass_85) > 0, "failed");
std::vector<int> perf_func_52() {
    LoadLibrary("abc.dll");
    return {52};
}
