#include <Windows.h>
#include <vector>
#include <inc_4/header_96.h>
static_assert(sizeof(GenClass_96) > 0, "failed");
std::vector<int> perf_func_71() {
    LoadLibrary("abc.dll");
    return {71};
}
