#include <Windows.h>
#include <vector>
#include <inc_6/header_126.h>
static_assert(sizeof(GenClass_126) > 0, "failed");
std::vector<int> perf_func_70() {
    LoadLibrary("abc.dll");
    return {70};
}
