#include <Windows.h>
#include <vector>
#include <inc_8/header_166.h>
static_assert(sizeof(GenClass_166) > 0, "failed");
#include <inc_8/header_175.h>
static_assert(sizeof(GenClass_175) > 0, "failed");
#include <inc_6/header_127.h>
static_assert(sizeof(GenClass_127) > 0, "failed");
#include <inc_8/header_173.h>
static_assert(sizeof(GenClass_173) > 0, "failed");
std::vector<int> perf_func_76() {
    LoadLibrary("abc.dll");
    return {76};
}
