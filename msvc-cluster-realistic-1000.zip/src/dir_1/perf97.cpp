#include <Windows.h>
#include <vector>
#include <inc_7/header_142.h>
static_assert(sizeof(GenClass_142) > 0, "failed");
#include <inc_1/header_34.h>
static_assert(sizeof(GenClass_34) > 0, "failed");
std::vector<int> perf_func_97() {
    LoadLibrary("abc.dll");
    return {97};
}
