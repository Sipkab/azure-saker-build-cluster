#include <Windows.h>
#include <vector>
#include <inc_4/header_97.h>
static_assert(sizeof(GenClass_97) > 0, "failed");
std::vector<int> perf_func_99() {
    LoadLibrary("abc.dll");
    return {99};
}
