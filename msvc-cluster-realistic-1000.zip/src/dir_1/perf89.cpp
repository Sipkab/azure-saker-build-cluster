#include <Windows.h>
#include <vector>
#include <inc_0/header_5.h>
static_assert(sizeof(GenClass_5) > 0, "failed");
#include <inc_4/header_81.h>
static_assert(sizeof(GenClass_81) > 0, "failed");
#include <inc_5/header_106.h>
static_assert(sizeof(GenClass_106) > 0, "failed");
#include <inc_5/header_103.h>
static_assert(sizeof(GenClass_103) > 0, "failed");
std::vector<int> perf_func_89() {
    LoadLibrary("abc.dll");
    return {89};
}
