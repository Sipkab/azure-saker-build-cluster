#include <Windows.h>
#include <vector>
#include <inc_6/header_139.h>
static_assert(sizeof(GenClass_139) > 0, "failed");
std::vector<int> perf_func_600() {
    LoadLibrary("abc.dll");
    return {600};
}
