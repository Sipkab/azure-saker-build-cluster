#include <Windows.h>
#include <vector>
#include <inc_1/header_25.h>
static_assert(sizeof(GenClass_25) > 0, "failed");
std::vector<int> perf_func_603() {
    LoadLibrary("abc.dll");
    return {603};
}
