#include <Windows.h>
#include <vector>
#include <inc_8/header_173.h>
static_assert(sizeof(GenClass_173) > 0, "failed");
#include <inc_8/header_170.h>
static_assert(sizeof(GenClass_170) > 0, "failed");
#include <inc_9/header_189.h>
static_assert(sizeof(GenClass_189) > 0, "failed");
#include <inc_5/header_116.h>
static_assert(sizeof(GenClass_116) > 0, "failed");
#include <inc_9/header_196.h>
static_assert(sizeof(GenClass_196) > 0, "failed");
#include <inc_2/header_49.h>
static_assert(sizeof(GenClass_49) > 0, "failed");
std::vector<int> perf_func_628() {
    LoadLibrary("abc.dll");
    return {628};
}
