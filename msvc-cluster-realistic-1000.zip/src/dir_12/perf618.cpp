#include <Windows.h>
#include <vector>
#include <inc_5/header_119.h>
static_assert(sizeof(GenClass_119) > 0, "failed");
#include <inc_8/header_178.h>
static_assert(sizeof(GenClass_178) > 0, "failed");
std::vector<int> perf_func_618() {
    LoadLibrary("abc.dll");
    return {618};
}
