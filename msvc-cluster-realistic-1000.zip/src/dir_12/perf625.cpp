#include <Windows.h>
#include <vector>
#include <inc_8/header_166.h>
static_assert(sizeof(GenClass_166) > 0, "failed");
std::vector<int> perf_func_625() {
    LoadLibrary("abc.dll");
    return {625};
}
