#include <Windows.h>
#include <vector>
#include <inc_3/header_72.h>
static_assert(sizeof(GenClass_72) > 0, "failed");
std::vector<int> perf_func_605() {
    LoadLibrary("abc.dll");
    return {605};
}
