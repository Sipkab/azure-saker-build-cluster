#include <Windows.h>
#include <vector>
#include <inc_8/header_167.h>
static_assert(sizeof(GenClass_167) > 0, "failed");
std::vector<int> perf_func_624() {
    LoadLibrary("abc.dll");
    return {624};
}
