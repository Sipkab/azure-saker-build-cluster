#include <Windows.h>
#include <vector>
#include <inc_4/header_83.h>
static_assert(sizeof(GenClass_83) > 0, "failed");
std::vector<int> perf_func_633() {
    LoadLibrary("abc.dll");
    return {633};
}
