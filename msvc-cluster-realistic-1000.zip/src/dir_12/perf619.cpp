#include <Windows.h>
#include <vector>
#include <inc_8/header_173.h>
static_assert(sizeof(GenClass_173) > 0, "failed");
std::vector<int> perf_func_619() {
    LoadLibrary("abc.dll");
    return {619};
}
