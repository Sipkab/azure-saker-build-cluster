#include <Windows.h>
#include <vector>
#include <inc_9/header_185.h>
static_assert(sizeof(GenClass_185) > 0, "failed");
#include <inc_0/header_12.h>
static_assert(sizeof(GenClass_12) > 0, "failed");
#include <inc_0/header_2.h>
static_assert(sizeof(GenClass_2) > 0, "failed");
std::vector<int> perf_func_621() {
    LoadLibrary("abc.dll");
    return {621};
}
