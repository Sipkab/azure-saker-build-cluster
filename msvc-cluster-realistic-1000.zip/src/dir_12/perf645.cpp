#include <Windows.h>
#include <vector>
#include <inc_6/header_126.h>
static_assert(sizeof(GenClass_126) > 0, "failed");
#include <inc_0/header_17.h>
static_assert(sizeof(GenClass_17) > 0, "failed");
#include <inc_3/header_72.h>
static_assert(sizeof(GenClass_72) > 0, "failed");
#include <inc_4/header_84.h>
static_assert(sizeof(GenClass_84) > 0, "failed");
#include <inc_5/header_117.h>
static_assert(sizeof(GenClass_117) > 0, "failed");
std::vector<int> perf_func_645() {
    LoadLibrary("abc.dll");
    return {645};
}
