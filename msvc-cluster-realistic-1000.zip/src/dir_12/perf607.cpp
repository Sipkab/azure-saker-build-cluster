#include <Windows.h>
#include <vector>
#include <inc_5/header_108.h>
static_assert(sizeof(GenClass_108) > 0, "failed");
std::vector<int> perf_func_607() {
    LoadLibrary("abc.dll");
    return {607};
}
