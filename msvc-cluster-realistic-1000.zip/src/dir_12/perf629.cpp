#include <Windows.h>
#include <vector>
#include <inc_4/header_83.h>
static_assert(sizeof(GenClass_83) > 0, "failed");
#include <inc_9/header_194.h>
static_assert(sizeof(GenClass_194) > 0, "failed");
#include <inc_7/header_157.h>
static_assert(sizeof(GenClass_157) > 0, "failed");
std::vector<int> perf_func_629() {
    LoadLibrary("abc.dll");
    return {629};
}
