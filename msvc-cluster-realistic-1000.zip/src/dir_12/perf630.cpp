#include <Windows.h>
#include <vector>
#include <inc_0/header_2.h>
static_assert(sizeof(GenClass_2) > 0, "failed");
std::vector<int> perf_func_630() {
    LoadLibrary("abc.dll");
    return {630};
}
