#include <Windows.h>
#include <vector>
#include <inc_9/header_189.h>
static_assert(sizeof(GenClass_189) > 0, "failed");
std::vector<int> perf_func_648() {
    LoadLibrary("abc.dll");
    return {648};
}
