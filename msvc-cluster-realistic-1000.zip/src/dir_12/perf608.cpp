#include <Windows.h>
#include <vector>
#include <inc_4/header_92.h>
static_assert(sizeof(GenClass_92) > 0, "failed");
std::vector<int> perf_func_608() {
    LoadLibrary("abc.dll");
    return {608};
}
