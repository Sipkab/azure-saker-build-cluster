#include <Windows.h>
#include <vector>
#include <inc_3/header_66.h>
static_assert(sizeof(GenClass_66) > 0, "failed");
std::vector<int> perf_func_622() {
    LoadLibrary("abc.dll");
    return {622};
}
