#include <Windows.h>
#include <vector>
#include <inc_9/header_198.h>
static_assert(sizeof(GenClass_198) > 0, "failed");
std::vector<int> perf_func_643() {
    LoadLibrary("abc.dll");
    return {643};
}
