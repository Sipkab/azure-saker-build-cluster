#include <Windows.h>
#include <vector>
#include <inc_3/header_69.h>
static_assert(sizeof(GenClass_69) > 0, "failed");
std::vector<int> perf_func_598() {
    LoadLibrary("abc.dll");
    return {598};
}
