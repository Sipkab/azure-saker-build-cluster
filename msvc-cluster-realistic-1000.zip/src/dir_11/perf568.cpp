#include <Windows.h>
#include <vector>
#include <inc_8/header_170.h>
static_assert(sizeof(GenClass_170) > 0, "failed");
#include <inc_6/header_134.h>
static_assert(sizeof(GenClass_134) > 0, "failed");
#include <inc_6/header_124.h>
static_assert(sizeof(GenClass_124) > 0, "failed");
std::vector<int> perf_func_568() {
    LoadLibrary("abc.dll");
    return {568};
}
