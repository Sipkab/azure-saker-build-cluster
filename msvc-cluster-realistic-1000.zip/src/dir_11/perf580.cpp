#include <Windows.h>
#include <vector>
#include <inc_7/header_143.h>
static_assert(sizeof(GenClass_143) > 0, "failed");
#include <inc_9/header_199.h>
static_assert(sizeof(GenClass_199) > 0, "failed");
std::vector<int> perf_func_580() {
    LoadLibrary("abc.dll");
    return {580};
}
