#include <Windows.h>
#include <vector>
#include <inc_9/header_194.h>
static_assert(sizeof(GenClass_194) > 0, "failed");
std::vector<int> perf_func_565() {
    LoadLibrary("abc.dll");
    return {565};
}
