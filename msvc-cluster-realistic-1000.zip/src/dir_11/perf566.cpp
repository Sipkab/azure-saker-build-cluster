#include <Windows.h>
#include <vector>
#include <inc_9/header_188.h>
static_assert(sizeof(GenClass_188) > 0, "failed");
std::vector<int> perf_func_566() {
    LoadLibrary("abc.dll");
    return {566};
}
