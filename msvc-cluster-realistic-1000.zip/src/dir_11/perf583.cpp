#include <Windows.h>
#include <vector>
#include <inc_5/header_102.h>
static_assert(sizeof(GenClass_102) > 0, "failed");
std::vector<int> perf_func_583() {
    LoadLibrary("abc.dll");
    return {583};
}
