#include <Windows.h>
#include <vector>
#include <inc_0/header_16.h>
static_assert(sizeof(GenClass_16) > 0, "failed");
#include <inc_8/header_175.h>
static_assert(sizeof(GenClass_175) > 0, "failed");
std::vector<int> perf_func_597() {
    LoadLibrary("abc.dll");
    return {597};
}
