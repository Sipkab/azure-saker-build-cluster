#include <Windows.h>
#include <vector>
#include <inc_5/header_118.h>
static_assert(sizeof(GenClass_118) > 0, "failed");
std::vector<int> perf_func_587() {
    LoadLibrary("abc.dll");
    return {587};
}
