#include <Windows.h>
#include <vector>
#include <inc_4/header_82.h>
static_assert(sizeof(GenClass_82) > 0, "failed");
#include <inc_8/header_161.h>
static_assert(sizeof(GenClass_161) > 0, "failed");
std::vector<int> perf_func_582() {
    LoadLibrary("abc.dll");
    return {582};
}
