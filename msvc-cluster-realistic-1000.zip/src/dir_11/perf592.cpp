#include <Windows.h>
#include <vector>
#include <inc_9/header_187.h>
static_assert(sizeof(GenClass_187) > 0, "failed");
#include <inc_4/header_94.h>
static_assert(sizeof(GenClass_94) > 0, "failed");
std::vector<int> perf_func_592() {
    LoadLibrary("abc.dll");
    return {592};
}
