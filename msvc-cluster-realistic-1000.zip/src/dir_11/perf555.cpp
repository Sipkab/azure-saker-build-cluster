#include <Windows.h>
#include <vector>
#include <inc_3/header_63.h>
static_assert(sizeof(GenClass_63) > 0, "failed");
std::vector<int> perf_func_555() {
    LoadLibrary("abc.dll");
    return {555};
}
