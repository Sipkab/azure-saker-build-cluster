#include <Windows.h>
#include <vector>
#include <inc_5/header_116.h>
static_assert(sizeof(GenClass_116) > 0, "failed");
#include <inc_5/header_108.h>
static_assert(sizeof(GenClass_108) > 0, "failed");
std::vector<int> perf_func_599() {
    LoadLibrary("abc.dll");
    return {599};
}
