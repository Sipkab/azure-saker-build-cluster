#include <Windows.h>
#include <vector>
#include <inc_5/header_114.h>
static_assert(sizeof(GenClass_114) > 0, "failed");
std::vector<int> perf_func_550() {
    LoadLibrary("abc.dll");
    return {550};
}
