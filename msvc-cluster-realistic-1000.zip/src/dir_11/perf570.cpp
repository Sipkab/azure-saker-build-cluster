#include <Windows.h>
#include <vector>
#include <inc_7/header_141.h>
static_assert(sizeof(GenClass_141) > 0, "failed");
#include <inc_0/header_2.h>
static_assert(sizeof(GenClass_2) > 0, "failed");
std::vector<int> perf_func_570() {
    LoadLibrary("abc.dll");
    return {570};
}
