#include <Windows.h>
#include <vector>
#include <inc_6/header_137.h>
static_assert(sizeof(GenClass_137) > 0, "failed");
#include <inc_9/header_197.h>
static_assert(sizeof(GenClass_197) > 0, "failed");
std::vector<int> perf_func_558() {
    LoadLibrary("abc.dll");
    return {558};
}
