#include <Windows.h>
#include <vector>
#include <inc_7/header_142.h>
static_assert(sizeof(GenClass_142) > 0, "failed");
#include <inc_5/header_105.h>
static_assert(sizeof(GenClass_105) > 0, "failed");
std::vector<int> perf_func_572() {
    LoadLibrary("abc.dll");
    return {572};
}
