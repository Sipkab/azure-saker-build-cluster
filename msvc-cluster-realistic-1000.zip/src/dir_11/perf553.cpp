#include <Windows.h>
#include <vector>
#include <inc_9/header_196.h>
static_assert(sizeof(GenClass_196) > 0, "failed");
#include <inc_7/header_152.h>
static_assert(sizeof(GenClass_152) > 0, "failed");
std::vector<int> perf_func_553() {
    LoadLibrary("abc.dll");
    return {553};
}
