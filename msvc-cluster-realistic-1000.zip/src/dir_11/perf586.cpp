#include <Windows.h>
#include <vector>
#include <inc_1/header_31.h>
static_assert(sizeof(GenClass_31) > 0, "failed");
std::vector<int> perf_func_586() {
    LoadLibrary("abc.dll");
    return {586};
}
