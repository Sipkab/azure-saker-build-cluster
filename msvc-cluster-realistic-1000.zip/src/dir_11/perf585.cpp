#include <Windows.h>
#include <vector>
#include <inc_7/header_155.h>
static_assert(sizeof(GenClass_155) > 0, "failed");
std::vector<int> perf_func_585() {
    LoadLibrary("abc.dll");
    return {585};
}
