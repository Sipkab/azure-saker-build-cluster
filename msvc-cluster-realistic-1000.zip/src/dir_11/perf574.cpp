#include <Windows.h>
#include <vector>
#include <inc_7/header_150.h>
static_assert(sizeof(GenClass_150) > 0, "failed");
#include <inc_2/header_49.h>
static_assert(sizeof(GenClass_49) > 0, "failed");
std::vector<int> perf_func_574() {
    LoadLibrary("abc.dll");
    return {574};
}
