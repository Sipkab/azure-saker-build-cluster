#include <Windows.h>
#include <vector>
#include <inc_0/header_6.h>
static_assert(sizeof(GenClass_6) > 0, "failed");
#include <inc_5/header_110.h>
static_assert(sizeof(GenClass_110) > 0, "failed");
#include <inc_3/header_75.h>
static_assert(sizeof(GenClass_75) > 0, "failed");
std::vector<int> perf_func_596() {
    LoadLibrary("abc.dll");
    return {596};
}
