#include <Windows.h>
#include <vector>
#include <inc_3/header_66.h>
static_assert(sizeof(GenClass_66) > 0, "failed");
#include <inc_6/header_121.h>
static_assert(sizeof(GenClass_121) > 0, "failed");
#include <inc_9/header_180.h>
static_assert(sizeof(GenClass_180) > 0, "failed");
std::vector<int> perf_func_594() {
    LoadLibrary("abc.dll");
    return {594};
}
