#include <Windows.h>
#include <vector>
#include <inc_3/header_65.h>
static_assert(sizeof(GenClass_65) > 0, "failed");
#include <inc_6/header_133.h>
static_assert(sizeof(GenClass_133) > 0, "failed");
#include <inc_3/header_68.h>
static_assert(sizeof(GenClass_68) > 0, "failed");
#include <inc_5/header_117.h>
static_assert(sizeof(GenClass_117) > 0, "failed");
#include <inc_2/header_40.h>
static_assert(sizeof(GenClass_40) > 0, "failed");
std::vector<int> perf_func_573() {
    LoadLibrary("abc.dll");
    return {573};
}
