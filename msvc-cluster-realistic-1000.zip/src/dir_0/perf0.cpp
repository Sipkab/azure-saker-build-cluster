#include <Windows.h>
#include <vector>
#include <inc_3/header_67.h>
static_assert(sizeof(GenClass_67) > 0, "failed");
std::vector<int> perf_func_0() {
    LoadLibrary("abc.dll");
    return {0};
}
