#include <Windows.h>
#include <vector>
#include <inc_3/header_77.h>
static_assert(sizeof(GenClass_77) > 0, "failed");
std::vector<int> perf_func_24() {
    LoadLibrary("abc.dll");
    return {24};
}
