#include <Windows.h>
#include <vector>
#include <inc_5/header_104.h>
static_assert(sizeof(GenClass_104) > 0, "failed");
#include <inc_4/header_97.h>
static_assert(sizeof(GenClass_97) > 0, "failed");
std::vector<int> perf_func_19() {
    LoadLibrary("abc.dll");
    return {19};
}
