#include <Windows.h>
#include <vector>
#include <inc_9/header_191.h>
static_assert(sizeof(GenClass_191) > 0, "failed");
std::vector<int> perf_func_38() {
    LoadLibrary("abc.dll");
    return {38};
}
