#include <Windows.h>
#include <vector>
#include <inc_0/header_17.h>
static_assert(sizeof(GenClass_17) > 0, "failed");
std::vector<int> perf_func_4() {
    LoadLibrary("abc.dll");
    return {4};
}
