#include <Windows.h>
#include <vector>
#include <inc_9/header_194.h>
static_assert(sizeof(GenClass_194) > 0, "failed");
#include <inc_6/header_131.h>
static_assert(sizeof(GenClass_131) > 0, "failed");
#include <inc_3/header_73.h>
static_assert(sizeof(GenClass_73) > 0, "failed");
#include <inc_9/header_192.h>
static_assert(sizeof(GenClass_192) > 0, "failed");
std::vector<int> perf_func_27() {
    LoadLibrary("abc.dll");
    return {27};
}
