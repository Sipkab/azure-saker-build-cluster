#include <Windows.h>
#include <vector>
#include <inc_3/header_74.h>
static_assert(sizeof(GenClass_74) > 0, "failed");
std::vector<int> perf_func_28() {
    LoadLibrary("abc.dll");
    return {28};
}
