#include <Windows.h>
#include <vector>
#include <inc_3/header_73.h>
static_assert(sizeof(GenClass_73) > 0, "failed");
std::vector<int> perf_func_9() {
    LoadLibrary("abc.dll");
    return {9};
}
