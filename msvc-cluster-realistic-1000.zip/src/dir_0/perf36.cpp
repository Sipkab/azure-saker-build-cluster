#include <Windows.h>
#include <vector>
#include <inc_0/header_16.h>
static_assert(sizeof(GenClass_16) > 0, "failed");
std::vector<int> perf_func_36() {
    LoadLibrary("abc.dll");
    return {36};
}
