#include <Windows.h>
#include <vector>
#include <inc_7/header_151.h>
static_assert(sizeof(GenClass_151) > 0, "failed");
#include <inc_7/header_147.h>
static_assert(sizeof(GenClass_147) > 0, "failed");
#include <inc_8/header_178.h>
static_assert(sizeof(GenClass_178) > 0, "failed");
std::vector<int> perf_func_21() {
    LoadLibrary("abc.dll");
    return {21};
}
