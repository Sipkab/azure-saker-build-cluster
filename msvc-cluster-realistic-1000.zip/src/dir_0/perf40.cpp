#include <Windows.h>
#include <vector>
#include <inc_7/header_157.h>
static_assert(sizeof(GenClass_157) > 0, "failed");
#include <inc_4/header_96.h>
static_assert(sizeof(GenClass_96) > 0, "failed");
#include <inc_4/header_83.h>
static_assert(sizeof(GenClass_83) > 0, "failed");
#include <inc_4/header_96.h>
static_assert(sizeof(GenClass_96) > 0, "failed");
std::vector<int> perf_func_40() {
    LoadLibrary("abc.dll");
    return {40};
}
