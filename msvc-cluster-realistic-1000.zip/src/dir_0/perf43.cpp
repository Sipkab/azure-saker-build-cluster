#include <Windows.h>
#include <vector>
#include <inc_5/header_106.h>
static_assert(sizeof(GenClass_106) > 0, "failed");
std::vector<int> perf_func_43() {
    LoadLibrary("abc.dll");
    return {43};
}
