#include <Windows.h>
#include <vector>
#include <inc_5/header_117.h>
static_assert(sizeof(GenClass_117) > 0, "failed");
#include <inc_0/header_9.h>
static_assert(sizeof(GenClass_9) > 0, "failed");
std::vector<int> perf_func_41() {
    LoadLibrary("abc.dll");
    return {41};
}
