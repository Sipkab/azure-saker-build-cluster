#include <Windows.h>
#include <vector>
#include <inc_6/header_138.h>
static_assert(sizeof(GenClass_138) > 0, "failed");
std::vector<int> perf_func_49() {
    LoadLibrary("abc.dll");
    return {49};
}
